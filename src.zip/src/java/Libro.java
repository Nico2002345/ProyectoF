
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author nicol
 */
public class Libro extends LibroRevista {
    
    private String autor;
    private int paginas;
    
    public Libro(int id, String titulo,String autor,int paginas) {
        super(id, titulo);
        this.autor=autor;
        this.paginas=paginas;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }
  
   public void imprimirInformacion() {
        System.out.println("Título: " + getTitulo());
        System.out.println("Autor: " + autor);
        System.out.println("Páginas: " + paginas);
    } 
    
}
class Revista extends LibroRevista {
   private String autor;
    private int paginas;
    
    public Revista(int id, String titulo,String autor,int paginas) {
        super(id, titulo);
        this.autor=autor;
        this.paginas=paginas;
    }
    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }
  
   public void imprimirInformacion() {
        System.out.println("Título: " + getTitulo());
        System.out.println("Autor: " + autor);
        System.out.println("Páginas: " + paginas);
    } 
    
    
}
