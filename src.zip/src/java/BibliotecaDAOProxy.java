package java;




/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author nicol
 */
public abstract class BibliotecaDAOProxy implements BibliotecaDao {

    private BibliotecaDao realDAO;

    public BibliotecaDAOProxy() {
        realDAO = BibliotecaDatabase.getInstance();
    }

    public boolean existeSocio(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void agregarLibroRevista(LibroRevista libroRevista) {
        if (libroRevista.getTitulo() == null || libroRevista.getTitulo().isEmpty()) {
            throw new IllegalArgumentException("El título del libro/revista no puede estar vacío");
        }

        realDAO.agregarLibroRevista(libroRevista);
    }

    @Override
    public void actualizarLibroRevista(LibroRevista libroRevista) {
        realDAO.actualizarLibroRevista(libroRevista);
    }

    public void eliminarLibroRevista(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("El ID del libro/revista no puede estar vacío");
        }
        realDAO.eliminarLibroRevista(id);
    }

    public void agregarSocio(Socio socio) {
        if (existeSocio(socio.getId())) {
            throw new RuntimeException("El socio ya existe en la biblioteca.");
        }
        realDAO.agregarSocio(socio);
    }

    @Override
    public void actualizarSocio(Socio socio) {
        if (!existeSocio(socio.getId())) {
            throw new RuntimeException("El socio no existe en la biblioteca.");
        }
        realDAO.actualizarSocio(socio);
    }

    @Override
    public void solicitarPrestamo(Prestamo prestamo) {
        if (!realDAO.esLibroDisponible(prestamo.getIdLibro())) {
            throw new RuntimeException("El libro no está disponible para préstamo.");
        } else {
            if (!existeSocio(prestamo.getIdSocio())) {
                throw new RuntimeException("El socio no existe en la biblioteca.");
            }
        }
        realDAO.solicitarPrestamo(prestamo);
    }

    public void devolverLibroRevista(String idPrestamo) {
        if (!existePrestamo(idPrestamo)) {
            throw new RuntimeException("El préstamo no existe en la biblioteca.");
        }

        Prestamo prestamo = obtenerPrestamo(idPrestamo);

        realDAO.devolverLibroRevista(idPrestamo);
    }

    
}







    
   
    
    
    
   

    
    
     

