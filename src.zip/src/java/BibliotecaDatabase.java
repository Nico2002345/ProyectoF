
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class BibliotecaDatabase {
    private static BibliotecaDatabase instance;
    private Map<String, LibroRevista> librosRevistas;
    private Map<String, Socio> socios;
    private List<Prestamo> prestamos; 
    
     private BibliotecaDatabase() {
        librosRevistas = new HashMap<>();
        socios = new HashMap<>();
        prestamos = new ArrayList<>();
    }
    
    public static BibliotecaDatabase getInstance() {
        if (instance == null) {
            instance = new BibliotecaDatabase();
        }
        return instance;
    }
     public void agregarLibroRevista(LibroRevista libroRevista) {
        librosRevistas.put(libroRevista.getId(), libroRevista);
    }
    
    public void actualizarLibroRevista(LibroRevista libroRevista) {
        librosRevistas.put(libroRevista.getId(), libroRevista);
    }
    
    public void eliminarLibroRevista(String id) {
        librosRevistas.remove(id);
    }
    
    public List<LibroRevista> listarLibrosRevistas() {
        return new ArrayList<>(librosRevistas.values());
    }
    public List<Libro> buscarLibros(String titulo) {
        List<Libro> librosEncontrados = new ArrayList<>();
        for (LibroRevista libroRevista : librosRevistas.values()) {
            if (libroRevista instanceof Libro && libroRevista.getTitulo().equalsIgnoreCase(titulo)) {
                librosEncontrados.add((Libro) libroRevista);
            }
        }
        return librosEncontrados;
    }
    
    public void agregarSocio(Socio socio) {
        socios.put(socio.getId(), socio);
    }
    
    public void actualizarSocio(Socio socio) {
        socios.put(socio.getId(), socio);
    }
     public void eliminarSocio(String id) {
        socios.remove(id);
    }
    
    public Socio consultarSocio(String id) {
        return socios.get(id);
    }
    
    public List<Socio> listarSocios() {
        return new ArrayList<>(socios.values());
    }
    
    public void solicitarPrestamo(Prestamo prestamo) {
        prestamos.add(prestamo);
    }
      public void devolverLibroRevista(String idPrestamo) {
        for (Prestamo prestamo : prestamos) {
            if (prestamo.getId().equals(idPrestamo)) {
                prestamos.remove(prestamo);
                break;
            }
        }
    }
    
    public boolean comprobarDisponibilidad(String idLibroRevista) {
        for (Prestamo prestamo : prestamos) {
            if (prestamo.getLibroRevista().getId().equals(idLibroRevista)) {
                return false;
            }
        }
        return true;
    }
    
    public void extenderPrestamo(String idPrestamo) {
        for (Prestamo prestamo : prestamos) {
            if (prestamo.getId().equals(idPrestamo)) {
               
                break;
            }
        }
    }
}

