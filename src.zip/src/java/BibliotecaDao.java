
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author nicol
 */
public interface BibliotecaDao {

    public abstract boolean existeLibroRevista(String idLibroRevista);

    public abstract  boolean existeSocio(String id);

    public abstract boolean existePrestamo(String idPrestamo);

    public abstract Prestamo obtenerPrestamo(String idPrestamo);
     void agregarLibroRevista(LibroRevista libroRevista);
    void actualizarLibroRevista(LibroRevista libroRevista);
    void eliminarLibroRevista(String id);
    List<LibroRevista> listarLibrosRevistas();
    List<Libro> buscarLibros(String titulo);
    void agregarSocio(Socio socio);
    void actualizarSocio(Socio socio);
    void eliminarSocio(String id);
    Socio consultarSocio(String id);
    List<Socio> listarSocios();
    void solicitarPrestamo(Prestamo prestamo);
    void devolverLibroRevista(String idPrestamo);
    boolean comprobarDisponibilidad(String idLibroRevista);
    void extenderPrestamo(String idPrestamo);

    @Override
    public String toString();

    @Override
    public boolean equals(Object obj);

    @Override
    public int hashCode();

    public LibroRevista buscarLibroRevista(String idLibro);

    public boolean existeLibro(String idLibro);

    public Libro obtenerLibro(String idLibro);

    public void actualizarLibro(Libro libro);

    
    
}