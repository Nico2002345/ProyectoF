
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author nicol
 */
public class BibliotecaApp {

    public static void main(String[] args) {
        BibliotecaDao realDAO = BibliotecaDatabase.getInstance();
        BibliotecaDAOProxy daoProxy = new BibliotecaDAOProxy(realDAO);
        PrestamoService prestamoService = new PrestamoServiceImpl(daoProxy);
        PrestamoServiceDecorator prestamoServiceDecorator = new PrestamoServiceDecorator(prestamoService);
        Biblioteca biblioteca = new Biblioteca(daoProxy);

        Libro libro = new Libro("L1", "Libro 1");
        biblioteca.agregarLibroRevista(libro);

        List<LibroRevista> librosRevistas = biblioteca.listarLibrosRevistas();
        for (LibroRevista libroRevista : librosRevistas) {
            System.out.println(libroRevista.getTitulo());
        }

        Socio socio = new Socio("S1", "Juan");
        Prestamo prestamo = new Prestamo("P1", socio, libro);
        prestamoService.solicitarPrestamo(prestamo);

        prestamoService.extenderPrestamo("P1");

        biblioteca.libroReservado("S1", "L1");
    }
}


   
