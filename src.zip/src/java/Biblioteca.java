
/**
 *
 * @author nicol
 */
public abstract class Biblioteca implements ReservaObserver{
    private BibliotecaDao bibliotecaDao;
    
    public Biblioteca(BibliotecaDao bibliotecaDao) {
        this.bibliotecaDao = bibliotecaDao;
    }
    
    @Override
    public void libroReservado(String idSocio, String idLibro) {
        Socio socio = bibliotecaDao.consultarSocio(idSocio);
        LibroRevista libro = bibliotecaDao.buscarLibroRevista(idLibro);

     String mensaje = "Estimado " + socio.getNombre() + ", el libro " + libro.getTitulo() + " ha sido reservado para usted.";
        enviarNotificacion(socio, mensaje);
        
        
        libro.setDisponible(false);
        bibliotecaDao.actualizarLibroRevista(libro);
    }    
        public void actualizarDisponibilidadLibro(String idLibro, boolean disponible) {
    
    if (!bibliotecaDao.existeLibro(idLibro)) {
        throw new RuntimeException("El libro no existe en la biblioteca.");
    }
    
    
    Libro libro = bibliotecaDao.obtenerLibro(idLibro);
    
    
    libro.setDisponible(disponible);
    
    
    bibliotecaDao.actualizarLibro(libro);
}

    private void enviarNotificacion(Socio socio, String mensaje) {
        throw new UnsupportedOperationException("Ya reservaste el Libro"); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
    }


