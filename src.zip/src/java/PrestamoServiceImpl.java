/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author nicol
 */
public abstract class PrestamoServiceImpl implements PrestamoService {
  private BibliotecaDao bibliotecaDao;
    
    public PrestamoServiceImpl(BibliotecaDao bibliotecaDao) {
        this.bibliotecaDao = bibliotecaDao;
    }
    
    public void solicitarPrestamo(Prestamo prestamo) {
        if (!bibliotecaDao.existeLibroRevista(prestamo.getIdLibroRevista())) {
            throw new RuntimeException("El libro/revista no existe en la biblioteca.");
        }
    
        // Verificar si el socio existe en la biblioteca
        if (!bibliotecaDao.existeSocio(prestamo.getIdSocio())) {
            throw new RuntimeException("El socio no existe en la biblioteca.");
        }
        
        bibliotecaDao.solicitarPrestamo(prestamo);
    }
    
    @Override
    public void extenderPrestamo(String idPrestamo) {
        
        
        bibliotecaDao.extenderPrestamo(idPrestamo);
     

}
}
