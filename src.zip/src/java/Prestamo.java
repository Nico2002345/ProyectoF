package java;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author nicol
 */
public class Prestamo {
    private String id;
    private String Socio ;
    private String LibroRevista;

    public Prestamo(String id, String Socio, String LibroRevista) {
        this.id = id;
        this.Socio = Socio;
        this.LibroRevista = LibroRevista;
    }

    public Prestamo(String p1, Socio socio, Libro libro) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSocio() {
        return Socio;
    }

    public void setSocio(String Socio) {
        this.Socio = Socio;
    }

    public String getLibroRevista() {
        return LibroRevista;
    }

    public void setLibroRevista(String LibroRevista) {
        this.LibroRevista = LibroRevista;
    }

    String getIdSocio() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getIdLibroRevista() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
