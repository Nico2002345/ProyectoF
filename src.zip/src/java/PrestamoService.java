/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author nicol
 */
public interface PrestamoService {

    public abstract boolean existeSocio(String idSocio);

    public abstract boolean existePrestamo(String idPrestamo);

    public abstract Socio obtenerSocioPorPrestamo(String idPrestamo);

    public abstract boolean existeLibroRevista(String id);
      void solicitarPrestamo(Prestamo prestamo);
    void extenderPrestamo(String idPrestamo);
}

