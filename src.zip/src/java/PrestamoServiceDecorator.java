/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author nicol
 */
public abstract class PrestamoServiceDecorator implements PrestamoService {
    private PrestamoService realService;
    
    public PrestamoServiceDecorator(PrestamoService realService) {
        this.realService = realService;
    }
    
    @Override
    public void solicitarPrestamo(Prestamo prestamo) {
        if (!realService.existeLibroRevista(prestamo.getId())) {
            throw new RuntimeException("El libro/revista no existe en la biblioteca.");
        }
        if (!realService.existeSocio(prestamo.getIdSocio())) {
            throw new RuntimeException("El socio no existe en la biblioteca.");
        } 
        realService.solicitarPrestamo(prestamo);
    }
    
    @Override
    public void extenderPrestamo(String idPrestamo) {
        if (!realService.existePrestamo(idPrestamo)) {
            throw new RuntimeException("El préstamo no existe en la biblioteca.");
        }
    
        Socio socio = realService.obtenerSocioPorPrestamo(idPrestamo);
        String mensaje = "Estimado " + socio.getNombre() + ", su préstamo ha sido extendido.";
    
        realService.extenderPrestamo(idPrestamo);
    }
}






